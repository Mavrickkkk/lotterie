import java.util.ArrayList;

public class Event extends java.util.EventObject {

    private ArrayList<Integer> nG;

    public Event(Lotterie l, ArrayList<Integer> nG) {
        super(l);
        this.nG = nG;
    }

    public ArrayList<Integer> getNumerosGagnant() {
        return nG;
    }
}
