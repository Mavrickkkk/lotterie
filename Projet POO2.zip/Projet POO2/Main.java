import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Lotterie l = new Lotterie(5, 50, 2);
        Joueur j1 = new Joueur("Carl", 0.0);
        l.addEventListener(j1);

        l.sellTicketCatI(j1);
        l.sellTicketCatI(j1);
        l.sellTicketCatI(j1);

        l.tirage();
        System.out.println("Les numéros gagnant sont : " + l.getNumerosGagnant());

        System.out.println(j1);

        System.out.println("Mes billets gagnant " + j1.mesBilletsGagnants(2));

        // sérialisation
        l.saveTicketToDisk(l.lb.billets);

        // désérialisation
        ArrayList<Billet> billets = l.loadTicketsFromDisk();

        // affichage des billets dérialisés
        for (Billet billet : billets) {
            System.out.println(billet);
        }
    }
}
