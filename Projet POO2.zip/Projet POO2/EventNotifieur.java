import javax.swing.event.EventListenerList;

public class EventNotifieur {
    private EventListenerList listenerList = new EventListenerList();

    public void addEventListener(EventListener listener) {
        listenerList.add(EventListener.class, listener);
    }

    public void removeEventListener(EventListener listener) {
        listenerList.remove(EventListener.class, listener);
    }

    public void diffuserEvent(Event evt) {
        Object[] listeners = listenerList.getListenerList();
        for (int i = 0; i < listeners.length; i = i + 2) {
            ((EventListener) listeners[i + 1]).actionADeclancher(evt);
        }
    }
}
