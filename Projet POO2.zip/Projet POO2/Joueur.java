import java.util.*;

public class Joueur implements EventListener {

    String nom;
    Double argent;
    ArrayList<Billet> mesBillets; // Billets achetés
    ArrayList<Integer> numGagnant; // Liste des numéros gagnant propagée par l'instance de Lotterie

    Joueur(String name, Double m) {
        this.nom = name;
        argent = m;
        mesBillets = new ArrayList<Billet>();
        numGagnant = new ArrayList<Integer>();
    }

    public String getNom() {
        return this.nom;
    }

    public Double getArgent() {
        return this.argent;
    }

    public ArrayList<Billet> getMesBillets() {
        return mesBillets;
    }

    public String toString() {
        return "Joueur : " + getNom() +
                " Argent : " + getArgent() +
                " Mes billets : " + getMesBillets();
    }

    // Méthode qui permet à un joueur de vérifier selon t ses billets gagnant
    public ArrayList<Billet> mesBilletsGagnants(int t) {
        ArrayList<Billet> billetsG = new ArrayList<>();

        for (Billet b : mesBillets) {
            int numerosCorrespondants = 0;
            for (Integer numero : b.getNumbers()) {
                if (numGagnant.contains(numero)) {
                    numerosCorrespondants++;
                }
            }
            if (numerosCorrespondants >= t) {
                billetsG.add(b);
            }
        }

        return billetsG;
    }

    public void actionADeclancher(Event event) {
        if (event.getSource() instanceof Lotterie
                && event.getNumerosGagnant() instanceof ArrayList<?>) {
            numGagnant = (ArrayList<Integer>) event.getNumerosGagnant();
        }
    }
}
