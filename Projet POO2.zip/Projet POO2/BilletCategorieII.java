import java.util.ArrayList;
import java.util.Scanner;

public class BilletCategorieII extends Billet {

    BilletCategorieII(int k, int n) {
        super(choisirNombresUtilisateur(k, n), 2.0);
    }

    // Permet à l'utilisateur de choisir k numéros compris entre 1 et n
    private static ArrayList<Integer> choisirNombresUtilisateur(int k, int n) {

        ArrayList<Integer> numeros = new ArrayList<>(k);
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choisissez " + k + " numéros entre 1 et " + n + ":");

        for (int i = 0; i < k; i++) {
            int numeroChoisi;

            do {
                System.out.print("Numéro " + (i + 1) + ": ");
                while (!scanner.hasNextInt()) {
                    System.out.println("Veuillez entrer un nombre entier.");
                    scanner.next();
                }
                numeroChoisi = scanner.nextInt();
            } while (numeroChoisi < 1 || numeroChoisi > n || numeros.contains(numeroChoisi));

            numeros.add(numeroChoisi);
        }

        scanner.close();

        return numeros;
    }
}
