public interface EventListener extends java.util.EventListener {
    public void actionADeclancher(Event evt);
}
