import java.util.ArrayList;

public class ListeBillet {

    ArrayList<Billet> billets;

    ListeBillet() {
        billets = new ArrayList<>();
    }

    public void add(Billet b) {
        billets.add(b);
    }
}
