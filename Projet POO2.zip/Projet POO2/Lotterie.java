import java.io.*;
import java.util.*;

public class Lotterie {

    private ArrayList<Integer> numerosGagnant;
    public ListeBillet lb;
    public int k, n, t;
    private EventNotifieur notifieur = new EventNotifieur();

    Lotterie(int k, int n, int t) {
        numerosGagnant = new ArrayList<>(k);
        this.lb = new ListeBillet();
        this.k = k;
        this.n = n;
        this.t = t;
    }

    public ArrayList<Integer> getNumerosGagnant() {
        return this.numerosGagnant;
    }

    public void addEventListener(EventListener listener) {
        notifieur.addEventListener(listener);
    }

    public void removeEventListener(EventListener listener) {
        notifieur.removeEventListener(listener);
    }

    // Méthode pour vendre un billet de catégorie 1
    public void sellTicketCatI(Joueur j) {

        BilletCategorieI b = new BilletCategorieI(k, n);

        if (j.argent >= b.getPrix()) {

            while (numeroSerieExisteDeja(b.getSerialNumber())) {
                b.genererNumeroSerie();
            }

            lb.add(b);
            j.mesBillets.add(b);
        } else {
            System.out.println("Vous n'avez pass assez d'argent pour acheter ce billet.");
        }
    }

    // Méthode pour acheter un billet de catégorie 2
    public void sellTicketCatII(Joueur j) {
        BilletCategorieII b = new BilletCategorieII(k, n);

        if (j.argent >= b.getPrix()) {

            while (numeroSerieExisteDeja(b.getSerialNumber())) {
                b.genererNumeroSerie();
            }

            lb.add(b);
            j.mesBillets.add(b);
        } else {
            System.out.println("Vous n'avez pass assez d'argent pour acheter ce billet.");
        }
    }

    // Méthode pour vérifier si un numéro de série existe déjà dans la liste de tous
    // les billets de la lotterie
    private boolean numeroSerieExisteDeja(String numeroSerie) {

        if (lb != null) {
            for (Billet billet : lb.billets) {
                if (billet.getSerialNumber().equals(numeroSerie)) {
                    return true; // Le numéro de série existe déjà
                }
            }
        }
        return false; // Le numéro de série est unique
    }

    // Méthode pour enregistrer un billet sur le disque
    public void saveTicketToDisk(ArrayList<Billet> billets) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("billet.txt"))) {
            out.writeObject(billets);
            System.out.println("Objets Billets sérialisés avec succès.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour charger les billets depuis le disque
    public ArrayList<Billet> loadTicketsFromDisk() {
        ArrayList<Billet> billets = new ArrayList<>();

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("billet.txt"))) {
            Object obj = in.readObject();
            if (obj instanceof ArrayList) {
                billets = (ArrayList<Billet>) obj;
            }
        } catch (EOFException e) {
            // Fin de fichier atteinte
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return billets;
    }

    // Tirage des numéros gagnant
    public void tirage() {

        Random random = new Random();

        for (int i = 0; i < k; i++) {
            int randomNum = random.nextInt(n) + 1;

            // Vérifier si le nombre est déjà dans la liste
            while (numerosGagnant.contains(randomNum)) {
                randomNum = random.nextInt(n) + 1; // Générer un nouveau nombre
            }

            numerosGagnant.add(randomNum);
        }

        notifieur.diffuserEvent(new Event(this, numerosGagnant));
    }
}
