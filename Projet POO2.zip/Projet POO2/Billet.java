import java.io.Serializable;
import java.util.*;

public class Billet implements Serializable {
    private String serialNumber; // Numéro de série unique du billet
    protected Double prix;
    protected ArrayList<Integer> numbers; // Nombres choisis par le serveur ou le joueur

    public Billet(ArrayList<Integer> numbers, Double prix) {
        this.serialNumber = genererNumeroSerie();
        this.numbers = numbers;
        this.prix = prix;
    }

    public ArrayList<Integer> getNumbers() {
        return numbers;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public Double getPrix() {
        return prix;
    }

    public String genererNumeroSerie() {
        int longueur = 20;
        String caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuilder numeroSerie = new StringBuilder();

        for (int i = 0; i < longueur; i++) {
            int index = random.nextInt(caracteres.length());
            numeroSerie.append(caracteres.charAt(index));
        }

        return numeroSerie.toString();
    }

    @Override
    public String toString() {
        return "Billet{" +
                "serialNumber='" + serialNumber + '\'' +
                ", numbers=" + numbers +
                '}';
    }
}
