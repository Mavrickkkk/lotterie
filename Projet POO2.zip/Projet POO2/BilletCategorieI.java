import java.util.*;

public class BilletCategorieI extends Billet {

    BilletCategorieI(int k, int n) {
        super(genererNombresAleatoires(k, n), 1.0);
    }

    // Retourne une liste de k numéro compris entre 1 et n
    private static ArrayList<Integer> genererNombresAleatoires(int k, int n) {
        ArrayList<Integer> numeros = new ArrayList<>(k);
        Random random = new Random();

        for (int i = 0; i < k; i++) {
            int randomNum = random.nextInt(n) + 1;

            // Vérifier si le nombre est déjà dans la liste
            while (numeros.contains(randomNum)) {
                randomNum = random.nextInt(n) + 1; // Générer un nouveau nombre
            }

            numeros.add(randomNum);
        }

        return numeros;
    }
}
